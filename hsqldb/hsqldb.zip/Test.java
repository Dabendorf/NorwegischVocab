

class Test
{
	public static void main(String[] args) throws Exception
	{
		//Datenbankzugriff.getSonnensysteme();
		System.out.println("Test Klasse");

	}
}